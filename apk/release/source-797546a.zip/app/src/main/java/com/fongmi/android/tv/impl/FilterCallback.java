package com.fongmi.android.tv.impl;

import com.fongmi.android.tv.bean.Value;

public interface FilterCallback {

    void setFilter(String key, Value value);
}
