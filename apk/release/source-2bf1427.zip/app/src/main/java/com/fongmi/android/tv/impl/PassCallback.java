package com.fongmi.android.tv.impl;

public interface PassCallback {

    void setPass(String pass);
}
