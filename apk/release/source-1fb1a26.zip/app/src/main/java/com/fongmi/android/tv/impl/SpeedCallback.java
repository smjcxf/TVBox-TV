package com.fongmi.android.tv.impl;

public interface SpeedCallback {

    void setSpeed(float speed);
}
